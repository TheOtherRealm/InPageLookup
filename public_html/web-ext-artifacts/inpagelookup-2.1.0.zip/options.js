const commandNames = ["getSelectedPedia", "getSelectedTionary", "removeSelected"];
const options = [{ "name": "getSelectedPedia", "description": "Look up a highlighted word or phrase in Wikipedia", "shortcut": "Ctrl+Shift+1" }, { "name": "getSelectedTionary", "description": "Look up a highlighted word or phrase in Wiktionary", "shortcut": "Ctrl+Shift+2" }, { "name": "removeSelected", "description": "Hide the iframe", "shortcut": "Ctrl+Shift+~" }];
/**
 * Update the UI: set the value of the commands textboxs.
 */
async function updateUI() {
	let commands = await browser.commands.getAll();
	for (command of commands) {
		for (commandName of commandNames) {
			if (command.name === commandName) {
				// console.log(command.shortcut, commandNames[0]);
				document.querySelector('#' + commandName).value = command.shortcut;
			}
		}
	}
}
/**
 * Update the commands based on the input.
 */
async function updateShortcut() {
	// console.log(document.forms['options'][commandName].value);
	for (commandName of commandNames) {
		console.log(document.forms['options'][commandName].value);
		await browser.storage.sync.set({"options":[{
			name: commandName,
			shortcut: document.forms['options'][commandName].value
		}]});
	}
}
/**
 * Reset the commands and update the textbox.
 */
async function resetShortcut() {
	var o=JSON.parse(JSON.stringify(options));
	console.log({ "options": o});
	await browser.storage.sync.set({ "options": o});
	updateUI();
}
/**
 * Update the UI when the page loads.
 */
document.addEventListener('DOMContentLoaded', updateUI);
/**
 * Handle update and reset button clicks
 */
document.querySelector('#update').addEventListener('click', updateShortcut);
document.querySelector('#reset').addEventListener('click', resetShortcut);