/*
 Created		: Dec 2, 2017, 5:42:20 PM
 Author		: Aaron E-J <the at otherrealm.org>
 Copyright(C): 2020 Other Realm LLC
 This program is free software: you can redistribute it and/or modify
 it under the terms of the latest version of the GNU Affero General Public License as published by
 the Free Software Foundation, using at least version 3.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 GNU Affero General Public License for more details: 
 <http://www.gnu.org/licenses/>.
 */
/* global browser, top, self */
(function () {
	var selObj = '';
	selObj = window.getSelection();
	var nOfLookups = 0;
	var rightKeys=[{"name":"getSelectedPedia","description":"Look up a highlighted word or phrase in Wikipedia","shortcut":"Ctrl+Shift+1"},{"name":"getSelectedTionary","description":"Look up a highlighted word or phrase in Wiktionary","shortcut":"Ctrl+Shift+2"},{"name":"removeSelected","description":"Hide the iframe","shortcut":"Ctrl+Shift+~"}];
	var options=browser.storage.sync.get('options');
	options.then(combo,error);
	function combo(c){
		rightKeys=c;
		console.log(c,rightKeys);
	}
	function error(e){
		console.log(e,"error");
	}
	$(document).keydown(function (e) {
		if (e.ctrlKey && e.shiftKey && e.which === 49) {
			getSelectedPedia();
		}
		if (e.ctrlKey && e.shiftKey && e.which === 50) {
			getSelectedTionary();
		}
		if (e.ctrlKey && e.shiftKey && e.key === '~') {
			closeWiki();
		}
	});
	var getSelectedPedia = function (c) {
		selObj = window.getSelection();
		nOfLookups++;
		$('.wikiWrapper').append('<div class="wikiAddonDivRap" id="' + nOfLookups + '" style="position: fixed;  top:' + (nOfLookups * 10) + 'px;left:' + (nOfLookups * 10) + 'px"">' +
			'<div class="btnForTheAddon btn-large IconBtnForTheAddon" type="button" style="padding: 5px;font-family: Arial, Helvetica, sans-serif; font-size: 30px;" id="moveIconBtn"> + </div>' +
			'<a href="#" id="closeWikiBtn"><div type="button" class="btnForTheAddon removeIconBtn btn-large IconBtnForTheAddon" style="padding: 5px; font-size: 25px;font-family: Arial, Helvetica, sans-serif;" id="removeIconBtn"> x </div></a>' +
			'<iframe id="wikiFrameContent" allow-top-navigation style="" src="https://en.wikipedia.org/wiki/Special:Search/' + selObj + '"></iframe>' +
			'</div>');
		$(function () {
			$(".wikiAddonDivRap").draggable();
			$(".wikiAddonDivRap").resizable();
			$('.removeIconBtn').click(function () {
				nOfLookups--;
				closeWiki();
			});
		});
	};
	var getSelectedTionary = function (c) {
		selObj = window.getSelection();
		nOfLookups++;
		$('.wikiWrapper').append('<div class="wikiAddonDivRap" id="' + nOfLookups + '" style="position: fixed;  top:' + nOfLookups * 10 + 'px;left:' + nOfLookups * 10 + 'px"">' +
			'<div class="btnForTheAddon btn-large IconBtnForTheAddon" type="button" style="padding: 5px;font-family: Arial, Helvetica, sans-serif; font-size: 30px;" id="moveIconBtn"> + </div>' +
			'<a href="#" id="closeWikiBtn"><div type="button" class="btnForTheAddon removeIconBtn btn-large IconBtnForTheAddon" style="padding: 5px; font-size: 25px;font-family: Arial, Helvetica, sans-serif;" id="removeIconBtn"> x </div></a>' +
			'<iframe id="wikiFrameContent" allow-top-navigation style="" src="https://en.wiktionary.org/wiki/Special:Search/' + selObj + '"></iframe>' +
			'</div>');
		$(function () {
			$(".wikiAddonDivRap").draggable();
			$(".wikiAddonDivRap").resizable();
			$('.removeIconBtn').click(function () {
				nOfLookups--;
				closeWiki();
			});
		});
	};
	$('body').prepend('<div id="wikiWrap" class="wikiWrapper"></div>');
	//handle menu button pressing
	browser.runtime.onMessage.addListener(
		function (request, sender, sendResponse) {
			// console.log(request.wiki, document.activeElement);
			if (document.activeElement) {
				console.log('75', request, sendResponse);
				if (request.wiki === "getSelectedPedia") {
					getSelectedPedia();
				}
				if (request.wiki === "getSelectedTionary") {
					getSelectedTionary();
				}
				if (request.wiki === "removeSelected") {
					closeWiki();
				}
				if (request.commands) {
					console.log(request.commands);
				}
			}
		});
	//remove the iframe when the key combinations are pressed or the 'X' button is pressed
	window.addEventListener("message", closeWiki, false);
	addEventListener('message', function (e) {
		if (e.data === 'closeWiki') {
			closeWiki();
		}
	});
	var closeWiki = function (c) {
		if ($('.wikiWrapper>*').length <= 0) {
			parent.postMessage('closeWiki', '*');
		} else {
			$('.wikiWrapper>*').remove();
			nOfLookups--;
		}
	};
})(jQuery);